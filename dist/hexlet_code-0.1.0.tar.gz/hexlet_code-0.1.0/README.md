### Hexlet tests and linter status:
[![Actions Status](https://github.com/Maxim00se/python-project-49/actions/workflows/hexlet-check.yml/badge.svg)](https://github.com/Maxim00se/python-project-49/actions)
<a href="https://codeclimate.com/github/Maxim00se/python-project-49/maintainability"><img src="https://api.codeclimate.com/v1/badges/dc24f585ba6899fbdac7/maintainability" /></a>

# Brain Games

https://asciinema.org/a/ozImHZOT82Mvg04XrYklZyK7x
